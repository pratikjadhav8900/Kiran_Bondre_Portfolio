'use client'

import { useRef, useMemo } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { Float, MeshDistortMaterial, MeshWobbleMaterial, Sphere, Torus, Environment, Stars } from '@react-three/drei'
import { motion, useScroll, useTransform, useMotionValue, useSpring } from 'framer-motion'
import * as THREE from 'three'

// Hero 3D Scene - Floating geometric shapes with glow
function HeroGeometry() {
  const meshRef = useRef<THREE.Mesh>(null)
  const groupRef = useRef<THREE.Group>(null)
  
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.x = state.clock.elapsedTime * 0.1
      meshRef.current.rotation.y = state.clock.elapsedTime * 0.15
    }
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.elapsedTime * 0.05
    }
  })

  return (
    <group ref={groupRef}>
      {/* Main sphere with distortion */}
      <Float speed={2} rotationIntensity={0.5} floatIntensity={1}>
        <mesh ref={meshRef} scale={2}>
          <icosahedronGeometry args={[1, 4]} />
          <MeshDistortMaterial
            color="#00d4ff"
            envMapIntensity={0.4}
            clearcoat={1}
            clearcoatRoughness={0}
            metalness={0.9}
            roughness={0.1}
            distort={0.3}
            speed={2}
          />
        </mesh>
      </Float>

      {/* Orbiting rings */}
      <Float speed={1.5} rotationIntensity={1} floatIntensity={0.5}>
        <Torus args={[3, 0.05, 16, 100]} rotation={[Math.PI / 2, 0, 0]}>
          <meshStandardMaterial color="#00d4ff" emissive="#00d4ff" emissiveIntensity={0.5} />
        </Torus>
      </Float>

      <Float speed={1.2} rotationIntensity={0.8} floatIntensity={0.3}>
        <Torus args={[3.5, 0.03, 16, 100]} rotation={[Math.PI / 3, Math.PI / 4, 0]}>
          <meshStandardMaterial color="#7c3aed" emissive="#7c3aed" emissiveIntensity={0.3} />
        </Torus>
      </Float>

      {/* Small floating spheres */}
      {Array.from({ length: 8 }).map((_, i) => {
        const angle = (i / 8) * Math.PI * 2
        const radius = 4
        return (
          <Float key={i} speed={1 + i * 0.1} floatIntensity={0.5}>
            <Sphere
              args={[0.1, 16, 16]}
              position={[Math.cos(angle) * radius, Math.sin(angle) * 0.5, Math.sin(angle) * radius]}
            >
              <meshStandardMaterial color="#00d4ff" emissive="#00d4ff" emissiveIntensity={1} />
            </Sphere>
          </Float>
        )
      })}
    </group>
  )
}

export function HeroSpline() {
  const containerRef = useRef<HTMLDivElement>(null)
  const mouseX = useMotionValue(0)
  const mouseY = useMotionValue(0)

  const springConfig = { damping: 25, stiffness: 150 }
  const rotateX = useSpring(useTransform(mouseY, [-0.5, 0.5], [5, -5]), springConfig)
  const rotateY = useSpring(useTransform(mouseX, [-0.5, 0.5], [-5, 5]), springConfig)

  return (
    <motion.div
      ref={containerRef}
      className="relative w-full h-[500px] md:h-[600px] lg:h-[700px]"
      style={{
        perspective: 1000,
        rotateX,
        rotateY,
      }}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
    >
      {/* Glow effect behind */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0">
        <div 
          className="w-[80%] h-[80%] rounded-full blur-3xl opacity-30"
          style={{
            background: 'radial-gradient(circle, oklch(0.7 0.2 200 / 0.4) 0%, transparent 70%)',
          }}
        />
      </div>

      <Canvas camera={{ position: [0, 0, 8], fov: 45 }} className="!absolute inset-0">
        <ambientLight intensity={0.3} />
        <pointLight position={[10, 10, 10]} intensity={1} color="#00d4ff" />
        <pointLight position={[-10, -10, -10]} intensity={0.5} color="#7c3aed" />
        <HeroGeometry />
        <Stars radius={100} depth={50} count={1000} factor={4} fade speed={1} />
        <Environment preset="night" />
      </Canvas>
    </motion.div>
  )
}

// Business Impact 3D Scene - Vortex/energy visualization
function VortexGeometry() {
  const groupRef = useRef<THREE.Group>(null)
  const particlesRef = useRef<THREE.Points>(null)
  
  const particleCount = 2000
  const positions = useMemo(() => {
    const pos = new Float32Array(particleCount * 3)
    for (let i = 0; i < particleCount; i++) {
      const angle = (i / particleCount) * Math.PI * 20
      const radius = 0.5 + (i / particleCount) * 3
      const y = (i / particleCount) * 6 - 3
      pos[i * 3] = Math.cos(angle) * radius
      pos[i * 3 + 1] = y
      pos[i * 3 + 2] = Math.sin(angle) * radius
    }
    return pos
  }, [])

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = state.clock.elapsedTime * 0.2
    }
    if (particlesRef.current) {
      particlesRef.current.rotation.y = state.clock.elapsedTime * 0.3
    }
  })

  return (
    <group ref={groupRef}>
      {/* Particle vortex */}
      <points ref={particlesRef}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            count={particleCount}
            array={positions}
            itemSize={3}
          />
        </bufferGeometry>
        <pointsMaterial
          size={0.03}
          color="#00d4ff"
          transparent
          opacity={0.8}
          sizeAttenuation
        />
      </points>

      {/* Central glowing orb */}
      <Float speed={2} floatIntensity={0.5}>
        <Sphere args={[0.8, 32, 32]}>
          <MeshWobbleMaterial
            color="#00d4ff"
            emissive="#00d4ff"
            emissiveIntensity={0.5}
            factor={0.3}
            speed={2}
            metalness={0.8}
            roughness={0.2}
          />
        </Sphere>
      </Float>

      {/* Orbiting energy rings */}
      {[1.5, 2, 2.5].map((radius, i) => (
        <Float key={i} speed={1 + i * 0.3} rotationIntensity={0.5}>
          <Torus args={[radius, 0.02, 16, 100]} rotation={[Math.PI / (2 + i), i * 0.5, 0]}>
            <meshStandardMaterial
              color={i === 0 ? '#00d4ff' : i === 1 ? '#10b981' : '#7c3aed'}
              emissive={i === 0 ? '#00d4ff' : i === 1 ? '#10b981' : '#7c3aed'}
              emissiveIntensity={0.5}
              transparent
              opacity={0.7}
            />
          </Torus>
        </Float>
      ))}
    </group>
  )
}

export function BusinessImpactSpline() {
  const containerRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start end', 'end start'],
  })

  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.8, 1.1, 0.9])
  const opacity = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0, 1, 1, 0.5])

  return (
    <motion.div
      ref={containerRef}
      className="relative w-full h-[400px] md:h-[500px] lg:h-[600px]"
      style={{ scale, opacity }}
    >
      {/* Ambient glow */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div 
          className="w-full h-full rounded-full blur-3xl opacity-20"
          style={{
            background: 'conic-gradient(from 0deg, oklch(0.7 0.2 200 / 0.3), oklch(0.6 0.15 280 / 0.3), oklch(0.8 0.15 160 / 0.3), oklch(0.7 0.2 200 / 0.3))',
          }}
        />
      </div>

      <Canvas camera={{ position: [0, 0, 6], fov: 50 }} className="!absolute inset-0">
        <ambientLight intensity={0.2} />
        <pointLight position={[5, 5, 5]} intensity={1} color="#00d4ff" />
        <pointLight position={[-5, -5, 5]} intensity={0.5} color="#10b981" />
        <VortexGeometry />
        <Environment preset="night" />
      </Canvas>
    </motion.div>
  )
}

// Showcase 3D Scene - Laptop/screen visualization
function LaptopGeometry() {
  const groupRef = useRef<THREE.Group>(null)
  
  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.3) * 0.1
      groupRef.current.position.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.1
    }
  })

  return (
    <group ref={groupRef} position={[0, -0.5, 0]}>
      {/* Screen */}
      <mesh position={[0, 1.2, -0.1]} rotation={[-0.1, 0, 0]}>
        <boxGeometry args={[3.2, 2, 0.1]} />
        <meshStandardMaterial color="#1a1a2e" metalness={0.9} roughness={0.1} />
      </mesh>
      
      {/* Screen display */}
      <mesh position={[0, 1.2, 0]}>
        <planeGeometry args={[2.8, 1.7]} />
        <meshStandardMaterial
          color="#0a0a14"
          emissive="#00d4ff"
          emissiveIntensity={0.1}
        />
      </mesh>

      {/* Screen content - floating elements */}
      <Float speed={2} floatIntensity={0.2}>
        <mesh position={[0, 1.2, 0.1]}>
          <boxGeometry args={[0.8, 0.4, 0.02]} />
          <meshStandardMaterial color="#00d4ff" emissive="#00d4ff" emissiveIntensity={0.3} transparent opacity={0.8} />
        </mesh>
      </Float>
      <Float speed={1.5} floatIntensity={0.15}>
        <mesh position={[-0.8, 1.5, 0.1]}>
          <boxGeometry args={[0.5, 0.3, 0.02]} />
          <meshStandardMaterial color="#10b981" emissive="#10b981" emissiveIntensity={0.3} transparent opacity={0.8} />
        </mesh>
      </Float>
      <Float speed={1.8} floatIntensity={0.18}>
        <mesh position={[0.8, 0.9, 0.1]}>
          <boxGeometry args={[0.6, 0.35, 0.02]} />
          <meshStandardMaterial color="#7c3aed" emissive="#7c3aed" emissiveIntensity={0.3} transparent opacity={0.8} />
        </mesh>
      </Float>

      {/* Base/keyboard */}
      <mesh position={[0, 0, 0.8]} rotation={[Math.PI / 2, 0, 0]}>
        <boxGeometry args={[3.2, 2, 0.15]} />
        <meshStandardMaterial color="#1a1a2e" metalness={0.8} roughness={0.2} />
      </mesh>

      {/* Keyboard area */}
      <mesh position={[0, 0.08, 0.6]} rotation={[Math.PI / 2, 0, 0]}>
        <planeGeometry args={[2.8, 1.4]} />
        <meshStandardMaterial color="#0f0f1a" />
      </mesh>
    </group>
  )
}

export function ShowcaseSpline() {
  const containerRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start end', 'end start'],
  })

  const y = useTransform(scrollYProgress, [0, 1], [100, -100])
  const rotateX = useTransform(scrollYProgress, [0, 0.5, 1], [20, 0, -10])
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.9, 1, 0.95])

  return (
    <motion.div
      ref={containerRef}
      className="relative w-full h-[400px] md:h-[500px] lg:h-[600px]"
      style={{
        y,
        rotateX,
        scale,
        perspective: 1200,
      }}
    >
      {/* Screen glow */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div 
          className="w-[60%] h-[40%] blur-3xl opacity-30 translate-y-10"
          style={{
            background: 'radial-gradient(ellipse, oklch(0.7 0.2 200 / 0.5) 0%, transparent 70%)',
          }}
        />
      </div>

      <Canvas camera={{ position: [0, 2, 5], fov: 45 }} className="!absolute inset-0">
        <ambientLight intensity={0.3} />
        <pointLight position={[5, 5, 5]} intensity={1} color="#00d4ff" />
        <pointLight position={[-5, 3, 5]} intensity={0.5} color="#7c3aed" />
        <spotLight position={[0, 5, 5]} angle={0.3} penumbra={1} intensity={0.5} color="#ffffff" />
        <LaptopGeometry />
        <Environment preset="night" />
      </Canvas>
    </motion.div>
  )
}
